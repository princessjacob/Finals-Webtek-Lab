The uploaded files contains the UI customizations of the bootstrap template SB Admin version 2. Such customizations comply with our mockup design.
