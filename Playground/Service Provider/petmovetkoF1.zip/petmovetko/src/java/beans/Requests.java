package beans;

public class Requests {

    private final String spID;
    private final String spUsername;
    private final String spEmail;
    private final String spPassword;

    public Requests(String spID, String spUsername, String spEmail, String spPassword ){
        this.spID = spID;
        this.spUsername = spUsername;
        this.spEmail = spEmail;
        this.spPassword = spPassword;
    }
    
    public String getspID() {
        return spID;
    }

    public String getspUsername() {
        return spUsername;
    }
    
    public String getspEmail() {
        return spEmail;
    }

    public String getspPassword() {
        return spPassword;
    }

    public void put(String spID, Requests requests) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void addRequests(Requests get) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
