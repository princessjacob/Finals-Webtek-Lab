package listeners;

import beans.Requests;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class StartupListener implements ServletContextListener {

    private HashMap<Object, Object> request;
   
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try {
            ServletContext context = sce.getServletContext();
            
            String driver = context.getInitParameter("driver");
            String connStr = context.getInitParameter("connstr");
            String username = context.getInitParameter("username");
            String password = context.getInitParameter("password");
            
            BasicDataSource ds = new BasicDataSource();
            ds.setDriverClassName(driver);
            ds.setUrl(connStr);
            ds.setUsername(username);
            ds.setPassword(password);
            
            HashMap<String, Requests> requests = null;
            try (Connection conn = ds.getConnection(); Statement st = conn.createStatement()) {
                String sql = "SELECT * FROM petmovetko.service_provider;";
                try (ResultSet rs = st.executeQuery(sql)) {
                    request = new HashMap<>();
                    if (rs.first()) {
                        do {
                            Requests req = new Requests(
                                    rs.getString("spID"),
                                    rs.getString("spUsername"),
                                    rs.getString("spEmail"),
                                    rs.getString("spPassword"));
                            request.put(req.getspID(), requests);
                        } while (rs.next());
                    }
                }
            }
            
            context.setAttribute("requests", requests);
        } catch (SQLException e) {
            throw new RuntimeException("Cannot start application.  Database access error.");
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Application shutdown.");
    }

    private static class BasicDataSource {

        public BasicDataSource() {
        }

        private Connection getConnection() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void setPassword(String password) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void setUsername(String username) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void setUrl(String connStr) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        private void setDriverClassName(String driver) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }
}
