package servlets;

import beans.Requests;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "Accept", urlPatterns = {"/Accpet"})
public class Accept extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        
        if (session == null || session.getAttribute("user") == null) {
            String url = response.encodeRedirectURL("index.jsp");
            response.sendRedirect(url);
        } else {
            String reqUser = request.getParameter("spUsername");
            
            HashMap<String,Requests> Requests = (HashMap<String, Requests>) this.getServletContext().getAttribute("Requests");
            
            Requests requests;
            requests = (Requests) (HttpServletRequest) (Requests) session.getAttribute("requests");
            requests.addRequests(Requests.get(reqUser));
            
            String uname = requests.getspUsername();
            
            
         request.getParameter(uname);   
         System.out.println("username: " + uname);
 
        // do some processing here...
         
        // get response writer
        PrintWriter writer = response.getWriter();
         
        // build HTML code
        request.getSession().setAttribute("user", uname);
        String htmlRespone = "<html>";
        htmlRespone += "<h2>Your username is: " + uname + "<br/>";    
        htmlRespone += "</html>";
         
        // return response
        writer.println(htmlRespone);
        
        request.getSession().setAttribute("user", "ako");    
            String url = response.encodeRedirectURL("requests.jsp");
            response.sendRedirect(url);
        }
    }
}
